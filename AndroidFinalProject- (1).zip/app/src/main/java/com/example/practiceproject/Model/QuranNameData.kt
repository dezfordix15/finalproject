package com.example.practiceproject.Model

data class QuranNameData(
    val code: Int,
    val data: List<DataX>,
    val status: String
)