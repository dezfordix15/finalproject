package com.example.practiceproject.Model

data class ZikrData(
    val number : Int,
    val name: String,
    val transkript : String,
    val counter : Int
)
