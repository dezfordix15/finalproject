package com.example.practiceproject.Model

data class Praytimes(
    val aqsham: String,
    val asriauual: String,
    val bamdat: String,
    val besin: String,
    val ekindi: String,
    val imsak: String,
    val isfirar: String,
    val ishaisani: String,
    val ishraq: String,
    val ishtibaq: String,
    val kerahat: String,
    val kun: String,
    val quptan: String
)