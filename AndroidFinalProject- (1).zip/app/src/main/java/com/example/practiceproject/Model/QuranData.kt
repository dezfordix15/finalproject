package com.example.practiceproject.Model

data class QuranData(
    val arabic : String,
    val translation: String,
    val numOfAyah : Int
)
