package com.example.practiceproject.Model

data class SceduleData(
    val date: Int,
    val eventName: String,
    val dateWeekDay: String,
    val dayLeft: Int
)
