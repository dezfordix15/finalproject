package com.example.practiceproject.Model

data class Data(
    val edition: Edition,
    val surahs: List<Surah>
)