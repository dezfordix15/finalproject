package com.example.practiceproject.Model

data class EntireQuranModel(
    val code: Int,
    val data: Data,
    val status: String
)