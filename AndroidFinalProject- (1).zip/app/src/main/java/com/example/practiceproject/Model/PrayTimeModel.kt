package com.example.practiceproject.Model

data class PrayTimeModel(
    val date: String,
    val islamic_date: String,
    val praytimes: Praytimes
)