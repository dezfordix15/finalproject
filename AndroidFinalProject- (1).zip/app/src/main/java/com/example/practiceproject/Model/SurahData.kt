package com.example.practiceproject.Model

import com.google.gson.annotations.SerializedName

data class SurahData(
     val number: Int,
     val name: String,
     val numOfAyahs: Int
)
